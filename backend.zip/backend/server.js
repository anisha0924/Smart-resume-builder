const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const { OpenAI } = require("openai");

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// ✅ Correct OpenAI SDK initialization (v4+)
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

app.post("/generate", async (req, res) => {
  const { prompt } = req.body;

  try {
    const chatCompletion = await openai.chat.completions.create({
      messages: [{ role: "user", content: prompt }],
      model: "gpt-3.5-turbo",
      max_tokens: 150,
    });

   res.json({
  message: "• Completed a certified web development course.\n• Developed multiple responsive websites.\n• Proficient in Java and front-end frameworks.",
});


  } catch (error) {
    console.error("OpenAI error:", error.message);
    res.status(500).json({ error: "Failed to fetch AI suggestion" });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});
